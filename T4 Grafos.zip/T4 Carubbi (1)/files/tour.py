from point import Point


class Tour:
    """
    Circuito TSP implementado como lista encadeada circular.
    Espelho de Tour.java — mesma estrutura de Node, mesmos métodos públicos.

    O Main insere cada ponto na ordem em que aparece no arquivo:
        for p in points:
            nearest.insertNearest(p)
            smallest.insertSmallest(p)

    Portanto cada método decide apenas ONDE inserir o novo ponto,
    não qual ponto inserir a seguir.
    """

    # ------------------------------------------------------------------
    # Nó interno da lista encadeada circular
    # ------------------------------------------------------------------
    class _Node:
        __slots__ = ("p", "next")

        def __init__(self, p: Point = None):
            self.p: Point = p
            self.next: "Tour._Node" = None

    # ------------------------------------------------------------------
    # Construtores
    # ------------------------------------------------------------------

    def __init__(self, a: Point = None, b: Point = None,
                 c: Point = None, d: Point = None):
        """
        Tour vazio  →  Tour()
        Tour 4 pts  →  Tour(a, b, c, d)  — a→b→c→d→a  (para debug)
        """
        self._start = self._Node()

        if a is not None:          # construtor de debug com 4 pontos
            nb = self._Node(b)
            nc = self._Node(c)
            nd = self._Node(d)
            self._start.p = a
            self._start.next = nb
            nb.next = nc
            nc.next = nd
            nd.next = self._start

    # ------------------------------------------------------------------
    # Métodos utilitários
    # ------------------------------------------------------------------

    def size(self) -> int:
        """Número de cidades no circuito."""
        if self._start.p is None:
            return 0
        count = 0
        cur = self._start
        while True:
            count += 1
            cur = cur.next
            if cur is self._start:
                break
        return count

    def length(self) -> float:
        """Comprimento total do circuito (fechado)."""
        if self._start.p is None:
            return 0.0
        total = 0.0
        cur = self._start
        while True:
            total += cur.p.distanceTo(cur.next.p)
            cur = cur.next
            if cur is self._start:
                break
        return total

    def __str__(self) -> str:
        if self._start.p is None:
            return ""
        parts = []
        cur = self._start
        while True:
            parts.append(str(cur.p))
            cur = cur.next
            if cur is self._start:
                break
        return "\n".join(parts)

    def nodes(self):
        """Gerador que percorre todos os nós do circuito (uso interno)."""
        if self._start.p is None:
            return
        cur = self._start
        while True:
            yield cur
            cur = cur.next
            if cur is self._start:
                break

    # ------------------------------------------------------------------
    # Heurísticas de inserção  ← FOCO DO TRABALHO
    # ------------------------------------------------------------------

    def insertNearest(self, p: Point) -> None:
        """
        Heurística Nearest Insertion.

        Encontra o nó do circuito atual cuja cidade está mais próxima de p
        e insere p imediatamente após esse nó.

        Caso especial: circuito vazio → p se torna o único nó, apontando
        para si mesmo (lista circular de um elemento).
        """
        # ── Caso 1: circuito vazio ────────────────────────────────────
        if self._start.p is None:
            self._start.p = p
            self._start.next = self._start   # aponta para si mesmo
            return

        # ── Passo 1: achar o nó mais próximo de p ────────────────────
        nearest_node = self._start
        min_dist = p.distanceTo(self._start.p)

        for node in self.nodes():
            d = p.distanceTo(node.p)
            if d < min_dist:
                min_dist = d
                nearest_node = node

        # ── Passo 2: inserir p logo após nearest_node ─────────────────
        #   nearest_node  →  new_node  →  (antigo next de nearest_node)
        new_node = self._Node(p)
        new_node.next = nearest_node.next
        nearest_node.next = new_node

    def insertSmallest(self, p: Point) -> None:
        """
        Heurística Smallest (Cheapest) Insertion.

        Para cada aresta (node → node.next) do circuito atual, calcula o
        custo de inserir p entre esses dois nós:

            custo = dist(node, p) + dist(p, node.next) − dist(node, node.next)

        Insere p na posição de menor custo incremental.

        Caso especial: circuito vazio → mesmo tratamento de insertNearest.
        """
        # ── Caso 1: circuito vazio ────────────────────────────────────
        if self._start.p is None:
            self._start.p = p
            self._start.next = self._start
            return

        # ── Caso 2: circuito com um único nó ─────────────────────────
        # Com apenas 1 nó a "aresta" é o laço para si mesmo; inserir após.
        if self._start.next is self._start:
            new_node = self._Node(p)
            new_node.next = self._start
            self._start.next = new_node
            return

        # ── Passo 1: encontrar a posição de menor aumento ────────────
        best_node = self._start
        min_increase = float("inf")

        for node in self.nodes():
            a = node.p
            b = node.next.p
            increase = a.distanceTo(p) + p.distanceTo(b) - a.distanceTo(b)
            if increase < min_increase:
                min_increase = increase
                best_node = node

        # ── Passo 2: inserir p entre best_node e best_node.next ───────
        new_node = self._Node(p)
        new_node.next = best_node.next
        best_node.next = new_node
