"""
T4 – Traveling Salesman Problem
Heurísticas: Nearest Insertion e Smallest Insertion

Espelho de Main.java — mesma lógica de leitura e inserção.

Uso:
    python main.py ../dados/tsp10.txt
    python main.py ../dados/usa13509.txt
"""

import sys
from point import Point
from tour import Tour
from visualizer import TSPVisualizer


def read_input(filepath: str):
    """
    Lê arquivo no formato:
        largura altura
        x0 y0
        x1 y1
        ...
    Retorna (width, height, [Point, ...])
    """
    with open(filepath) as f:
        tokens = f.read().split()

    it = iter(tokens)
    width  = int(next(it))
    height = int(next(it))

    points = []
    while True:
        try:
            x = float(next(it))
            y = float(next(it))
            points.append(Point(x, y))
        except StopIteration:
            break

    return width, height, points


def main():
    if len(sys.argv) < 2:
        print("Uso: python main.py <arquivo_entrada>")
        print("Ex.: python main.py ../dados/tsp10.txt")
        sys.exit(1)

    width, height, points = read_input(sys.argv[1])

    print("Instancia TSP carregada:")
    print(f"- dimensoes: {width} x {height}")
    print(f"- numero de pontos: {len(points)}")

    nearest  = Tour()
    smallest = Tour()

    # ── Inserção na ordem do arquivo (igual ao Main.java) ────────────
    for p in points:
        nearest.insertNearest(p)
        smallest.insertSmallest(p)

    print()
    print(f"Nearest  insertion: tamanho = {nearest.size():d}, "
          f"comprimento = {nearest.length():.4f}")
    print(f"Smallest insertion: tamanho = {smallest.size():d}, "
          f"comprimento = {smallest.length():.4f}")

    TSPVisualizer.showTours(width, height, points, nearest, smallest)


if __name__ == "__main__":
    main()
