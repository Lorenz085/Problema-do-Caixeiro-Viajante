"""
Visualizador TSP — espelho de TSPVisualizer.java.

nearest  → vermelho  (StdDraw.RED)
smallest → azul      (StdDraw.BLUE)
pontos   → preto     (StdDraw.BLACK)

Legenda no rodapé:
    num points: N
    nearest:  XXXX.XXXX
    smallest: XXXX.XXXX
"""

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from point import Point
from tour import Tour


class TSPVisualizer:
    BORDER = 70   # pixels de rodapé (igual à constante BORDER do Java)

    COLOR_NEAREST  = "#E63946"   # vermelho
    COLOR_SMALLEST = "#2563EB"   # azul
    COLOR_POINTS   = "#000000"   # preto

    @staticmethod
    def showTours(
        width: int,
        height: int,
        points: list,
        nearest: Tour,
        smallest: Tour,
    ) -> None:
        """
        Exibe os dois tours num único canvas, com legenda no rodapé.
        Comportamento equivalente a TSPVisualizer.showTours() + render().
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        fig.patch.set_facecolor("white")

        # Escala do canvas (equivale a setXscale / setYscale do StdDraw)
        ax.set_xlim(0, width)
        ax.set_ylim(-TSPVisualizer.BORDER, height)
        ax.set_aspect("equal")
        ax.axis("off")

        # ── Desenhar nearest (vermelho) ───────────────────────────────
        TSPVisualizer._draw_tour(ax, nearest,
                                 TSPVisualizer.COLOR_NEAREST,  lw=1.2)

        # ── Desenhar smallest (azul) ──────────────────────────────────
        TSPVisualizer._draw_tour(ax, smallest,
                                 TSPVisualizer.COLOR_SMALLEST, lw=0.9)

        # ── Desenhar pontos (preto, por cima das arestas) ─────────────
        if points:
            xs = [p.x for p in points]
            ys = [p.y for p in points]
            pt_size = max(1, 300 // len(points))
            ax.scatter(xs, ys, s=pt_size,
                       color=TSPVisualizer.COLOR_POINTS, zorder=3)

        # ── Rodapé (imita os três textLeft do Java) ───────────────────
        margin = 10
        ax.text(margin, -10,
                f"num points: {len(points)}",
                color="black", fontsize=9, va="top")
        ax.text(margin, -35,
                f"nearest:   {nearest.length():.4f}",
                color=TSPVisualizer.COLOR_NEAREST, fontsize=9, va="top",
                fontweight="bold")
        ax.text(margin, -60,
                f"smallest:  {smallest.length():.4f}",
                color=TSPVisualizer.COLOR_SMALLEST, fontsize=9, va="top",
                fontweight="bold")

        plt.tight_layout()
        plt.show()

    # ------------------------------------------------------------------
    @staticmethod
    def _draw_tour(ax, tour: Tour, color: str, lw: float) -> None:
        """Desenha todas as arestas do tour no eixo fornecido."""
        cities = list(tour.nodes()) if tour.size() > 0 else []
        n = len(cities)
        if n < 2:
            return
        for i in range(n):
            a = cities[i].p
            b = cities[(i + 1) % n].p
            ax.plot([a.x, b.x], [a.y, b.y],
                    color=color, linewidth=lw, alpha=0.8, zorder=1)
