import math


class Point:
    """Ponto 2D imutável — espelho de Point.java."""

    def __init__(self, x: float, y: float):
        self._x = x
        self._y = y

    @property
    def x(self) -> float:
        return self._x

    @property
    def y(self) -> float:
        return self._y

    def distanceTo(self, other: "Point") -> float:
        """Distância euclidiana entre este ponto e outro."""
        dx = self._x - other._x
        dy = self._y - other._y
        return math.sqrt(dx * dx + dy * dy)

    def __repr__(self):
        return f"({self._x}, {self._y})"
